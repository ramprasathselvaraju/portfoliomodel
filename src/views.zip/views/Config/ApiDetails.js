export const CREATE_STOCK = 'http://localhost:5008/stock_creation_api/';
export const GETSTOCKS = 'http://localhost:5008/stock_creation_api_list/';
export const GETSTOCKSLIST = 'http://localhost:5008/object_api_list/';
